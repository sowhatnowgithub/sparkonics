<?php

$user = "pavan";
$pass = "secret123";

?>
