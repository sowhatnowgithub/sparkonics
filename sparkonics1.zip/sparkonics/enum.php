<?php
enum userTypes
{
    case Public;
    case Admin;
}
?>
