<?php

$key = "isuckcauseisuck";
