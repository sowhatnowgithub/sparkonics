<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Error</title>
<?php echo "<style>" . Sowhatnow\App\Views\NavBar::$STYLE . "</style>"; ?>
</head>
<body>

    <?php echo Sowhatnow\App\Views\NavBar::$NAVBAR; ?>
     <div class="content" id="content-area">
       <h2>Welcome to the Website </h2>
       <p>You donot have the access for this page</p>
     </div>

</body>
</html>
