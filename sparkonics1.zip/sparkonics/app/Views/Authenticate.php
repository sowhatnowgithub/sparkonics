<?php

$authorisationDetails = "Authorization: ApiKey admin_secret_api_key";
$appkey = "admin_secret_key";
