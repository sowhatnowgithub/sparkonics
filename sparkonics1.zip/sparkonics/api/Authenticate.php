<?php
$VALID_API_ADMIN = "admin_secret_api_key";
$invalidKey = false;
$errorMessage = null;

if (
    strpos($request->server["request_uri"], "/delete") != false ||
    strpos($request->server["request_uri"], "/modify") != false ||
    strpos($request->server["request_uri"], "/add") != false
) {
    if (!isset($headers["authorization"])) {
        $invalidKey = true;
        $errorMessage = ["Error" => "Authorisation Header Missing"];
    } else {
        $authHeader = $headers["authorization"];
        list($type, $key) = explode(" ", $authHeader, 2);
        if ($type !== "ApiKey" || $key !== $VALID_API_ADMIN) {
            $invalidKey = true;
            $errorMessage = ["Error" => "Invalid Api Key"];
        }
    }
}

?>
